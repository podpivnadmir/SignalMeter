package com.signalmeter.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs

object IconRenderer {

    private const val SIZE = 96

    fun shortTechLabel(rawTech: String): String {
        val clean = rawTech.substringBefore(" (").trim()
        return when {
            clean.startsWith("5G+") -> "5G+"
            clean.startsWith("5G") -> "5G"
            clean == "LTE+" -> "4G+"
            clean == "LTE" -> "4G"
            clean == "3G" -> "3G"
            clean == "E" -> "E"
            clean == "G" -> "G"
            clean.startsWith("2G") -> "2G"
            else -> ""
        }
    }

    fun renderDbmIcon(
        dbm: Int?,
        showDataDot: Boolean = false,
        techLabel: String = ""
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val text = if (dbm != null) abs(dbm).toString() else "--"
        val badge = shortTechLabel(techLabel)
        val hasBadge = badge.isNotEmpty()

        if (!hasBadge) {
            val isThreeDigits = text.length >= 3
            val textSizeVal = if (showDataDot) {
                if (isThreeDigits) 50f else 62f
            } else {
                if (isThreeDigits) 60f else 70f
            }
            val scaleXVal = if (showDataDot) {
                if (isThreeDigits) 0.76f else 0.90f
            } else {
                if (isThreeDigits) 0.78f else 0.95f
            }

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.LEFT
                textSize = textSizeVal
                textScaleX = scaleXVal
            }

            val textWidth = paint.measureText(text)
            val dotRadius = if (showDataDot) 6.5f else 0f
            val dotGap = if (showDataDot) 8f else 0f
            val groupWidth = if (showDataDot) (dotRadius * 2f + dotGap + textWidth) else textWidth
            val groupStartX = ((SIZE - groupWidth) / 2f).coerceAtLeast(2f)

            val fm = paint.fontMetrics
            val y = (SIZE / 2f) - (fm.ascent + fm.descent) / 2f

            if (showDataDot) {
                val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(groupStartX + dotRadius, SIZE / 2f, dotRadius, dotPaint)
                canvas.drawText(text, groupStartX + dotRadius * 2f + dotGap, y, paint)
            } else {
                canvas.drawText(text, groupStartX, y, paint)
            }
            return bitmap
        }

        // With network type badge at top: clean two-zone layout for legibility
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            textSize = 25f
            textScaleX = 0.92f
        }
        val badgeFm = badgePaint.fontMetrics
        val badgeTop = 4f
        val badgeBottom = badgeTop + (badgeFm.descent - badgeFm.ascent) + 4f
        val badgeBaseline = badgeBottom - badgeFm.descent - 2f
        canvas.drawText(badge, SIZE / 2f, badgeBaseline, badgePaint)

        val numAreaTop = badgeBottom + 2f
        val numAreaBottom = SIZE - 3f
        val numAreaHeight = numAreaBottom - numAreaTop
        val numAreaCenterY = numAreaTop + numAreaHeight / 2f

        val isThreeDigits = text.length >= 3
        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            textSize = when {
                showDataDot && isThreeDigits -> 41f
                showDataDot -> 49f
                isThreeDigits -> 46f
                else -> 54f
            }
            textScaleX = if (isThreeDigits) 0.78f else 0.90f
        }

        val numWidth = numPaint.measureText(text)
        val dotRadius = if (showDataDot) 5.5f else 0f
        val dotGap = if (showDataDot) 6f else 0f
        val rowWidth = if (showDataDot) (dotRadius * 2f + dotGap + numWidth) else numWidth
        val rowStartX = ((SIZE - rowWidth) / 2f).coerceAtLeast(2f)

        val numFm = numPaint.fontMetrics
        val numBaseline = numAreaCenterY - (numFm.ascent + numFm.descent) / 2f

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(rowStartX + dotRadius, numAreaCenterY, dotRadius, dotPaint)
            canvas.drawText(text, rowStartX + dotRadius * 2f + dotGap, numBaseline, numPaint)
        } else {
            canvas.drawText(text, rowStartX, numBaseline, numPaint)
        }

        return bitmap
    }

    fun renderBarsIcon(
        bars: Int,
        showDataDot: Boolean = false,
        techLabel: String = ""
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val badge = shortTechLabel(techLabel)
        val hasBadge = badge.isNotEmpty()

        val barsTop: Float
        val barsBottom: Float
        if (hasBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                textSize = 25f
                textScaleX = 0.92f
            }
            val badgeFm = badgePaint.fontMetrics
            barsTop = 4f + (badgeFm.descent - badgeFm.ascent) + 8f
            barsBottom = SIZE - 6f
            canvas.drawText(badge, SIZE / 2f, 4f - badgeFm.ascent, badgePaint)
        } else {
            barsTop = 18f
            barsBottom = SIZE - 12f
        }

        val totalHeight = barsBottom - barsTop
        val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(75, 255, 255, 255)
            style = Paint.Style.FILL
        }

        val barWidth = 14f
        val gap = 6f
        val totalWidth = barWidth * 4 + gap * 3
        val dotSpace = if (showDataDot) 16f else 0f
        val startX = (((SIZE - (totalWidth + dotSpace)) / 2f) + dotSpace).coerceAtLeast(18f)
        val ratios = floatArrayOf(0.30f, 0.53f, 0.76f, 1.0f)
        val radius = 4.5f

        for (i in 0 until 4) {
            val barH = totalHeight * ratios[i]
            val left = startX + i * (barWidth + gap)
            val top = barsBottom - barH
            val rect = RectF(left, top, left + barWidth, barsBottom)
            canvas.drawRoundRect(rect, radius, radius, if (i < bars) activePaint else inactivePaint)
        }

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(9f, barsBottom - 6f, 5.8f, dotPaint)
        }

        if (bars == 0) {
            val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                strokeWidth = 6.5f
                strokeCap = Paint.Cap.ROUND
            }
            val xTop = barsTop + 4f
            val xSize = (totalHeight * 0.45f).coerceIn(14f, 22f)
            canvas.drawLine(startX, xTop, startX + xSize, xTop + xSize, xPaint)
            canvas.drawLine(startX + xSize, xTop, startX, xTop + xSize, xPaint)
        }

        return bitmap
    }
}
