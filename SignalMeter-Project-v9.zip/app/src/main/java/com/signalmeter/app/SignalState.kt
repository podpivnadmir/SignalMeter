package com.signalmeter.app

object SignalState {
    @Volatile
    var isRunning: Boolean = false

    @Volatile
    var currentDbm: Int? = null

    @Volatile
    var currentBars: Int = 0

    @Volatile
    var networkLabel: String = "Ожидание..."

    @Volatile
    var simLabel: String = "SIM"

    @Volatile
    var isReal5g: Boolean = false

    @Volatile
    var isDualMode: Boolean = false

    @Volatile
    var activeDataSlotIndex: Int? = null

    @Volatile
    var sim1Dbm: Int? = null

    @Volatile
    var sim2Dbm: Int? = null

    @Volatile
    var sim1Bars: Int = 0

    @Volatile
    var sim2Bars: Int = 0

    @Volatile
    var sim1Tech: String = "--"

    @Volatile
    var sim2Tech: String = "--"

    @Volatile
    var sim1Name: String = "SIM 1"

    @Volatile
    var sim2Name: String = "SIM 2"
}
