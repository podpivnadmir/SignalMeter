package com.signalmeter.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatusBadge: TextView
    private lateinit var tvDbmValue: TextView
    private lateinit var tvDetails: TextView
    private lateinit var tvCustomScaleSummary: TextView
    private lateinit var rgScale: RadioGroup
    private lateinit var swShowBarsInDbmMode: MaterialSwitch
    private lateinit var containerScaleSection: View

    private val uiHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            updateUiCard()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val phoneGranted = results[Manifest.permission.READ_PHONE_STATE] == true ||
            hasPermission(Manifest.permission.READ_PHONE_STATE)
        val notifGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            results[Manifest.permission.POST_NOTIFICATIONS] == true ||
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)

        if (phoneGranted && notifGranted) {
            startMonitorService()
        } else {
            Toast.makeText(
                this,
                "Нужны разрешения «Телефон» и «Уведомления» для показа сигнала",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatusBadge = findViewById(R.id.tvStatusBadge)
        tvDbmValue = findViewById(R.id.tvDbmValue)
        tvDetails = findViewById(R.id.tvDetails)
        tvCustomScaleSummary = findViewById(R.id.tvCustomScaleSummary)

        val btnStart = findViewById<MaterialButton>(R.id.btnStart)
        val btnStop = findViewById<MaterialButton>(R.id.btnStop)
        val btnAddScale = findViewById<MaterialButton>(R.id.btnAddScale)
        val btnAppSettings = findViewById<MaterialButton>(R.id.btnAppSettings)
        val rgIconMode = findViewById<RadioGroup>(R.id.rgIconMode)
        swShowBarsInDbmMode = findViewById(R.id.swShowBarsInDbmMode)
        containerScaleSection = findViewById(R.id.containerScaleSection)
        rgScale = findViewById(R.id.rgScale)
        val rgSimSlot = findViewById<RadioGroup>(R.id.rgSimSlot)
        val swAutostart = findViewById<MaterialSwitch>(R.id.swAutostart)

        refreshCustomScaleUi()
        updateScaleSectionVisibility()

        rgIconMode.check(
            if (Prefs.getIconMode(this) == Prefs.MODE_BARS) R.id.rbModeBars else R.id.rbModeDbm
        )
        swShowBarsInDbmMode.isChecked = Prefs.isShowBarsInDbmMode(this)

        when (Prefs.getScale(this)) {
            Prefs.SCALE_SOFT -> rgScale.check(R.id.rbScaleSoft)
            Prefs.SCALE_CUSTOM -> rgScale.clearCheck()
            else -> rgScale.check(R.id.rbScaleStrict)
        }

        rgSimSlot.check(
            when (Prefs.getSimSlot(this)) {
                Prefs.SIM_1 -> R.id.rbSim1
                Prefs.SIM_2 -> R.id.rbSim2
                Prefs.SIM_BOTH -> R.id.rbSimBoth
                else -> R.id.rbSimAuto
            }
        )
        swAutostart.isChecked = Prefs.isAutostart(this)

        btnAddScale.setOnClickListener {
            showCustomScaleDialog()
        }

        rgIconMode.setOnCheckedChangeListener { _, checkedId ->
            Prefs.setIconMode(
                this,
                if (checkedId == R.id.rbModeBars) Prefs.MODE_BARS else Prefs.MODE_DBM
            )
            updateScaleSectionVisibility()
            updateUiCard()
            refreshIfRunning()
        }

        swShowBarsInDbmMode.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setShowBarsInDbmMode(this, isChecked)
            updateScaleSectionVisibility()
            updateUiCard()
            refreshIfRunning()
        }

        rgScale.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == -1) return@setOnCheckedChangeListener
            val selected = when (checkedId) {
                R.id.rbScaleSoft -> Prefs.SCALE_SOFT
                else -> Prefs.SCALE_STRICT
            }
            Prefs.setScale(this, selected)
            refreshCustomScaleUi()
        updateScaleSectionVisibility()
            updateUiCard()
            refreshIfRunning()
        }

        rgSimSlot.setOnCheckedChangeListener { _, checkedId ->
            val slot = when (checkedId) {
                R.id.rbSim1 -> Prefs.SIM_1
                R.id.rbSim2 -> Prefs.SIM_2
                Prefs.SIM_BOTH -> Prefs.SIM_BOTH
                else -> Prefs.SIM_AUTO
            }
            Prefs.setSimSlot(this, slot)
            refreshIfRunning()
        }

        swAutostart.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setAutostart(this, isChecked)
        }

        btnStart.setOnClickListener {
            requestPermissionsAndStart()
        }

        btnStop.setOnClickListener {
            val stopIntent = Intent(this, SignalMonitorService::class.java).apply {
                action = SignalMonitorService.ACTION_STOP
            }
            startService(stopIntent)
            updateUiCard()
        }

        btnAppSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }
    }

    private fun updateScaleSectionVisibility() {
        val isDbmMode = Prefs.getIconMode(this) == Prefs.MODE_DBM
        swShowBarsInDbmMode.visibility = if (isDbmMode) View.VISIBLE else View.GONE

        val showBars = Prefs.isShowBarsInDbmMode(this)
        val shouldShow = !isDbmMode || showBars
        containerScaleSection.visibility = if (shouldShow) View.VISIBLE else View.GONE
    }

    private fun refreshCustomScaleUi() {
        val isCustomActive = Prefs.getScale(this) == Prefs.SCALE_CUSTOM
        if (Prefs.hasCustomThresholds(this)) {
            val t = Prefs.getCustomThresholds(this)
            val prefix = if (isCustomActive) "Активна своя шкала" else "Сохранённая своя шкала"
            tvCustomScaleSummary.text = "$prefix: ${Prefs.formatThresholds(t)} (1 дел. ≥ ${t[0]}, 2 ≥ ${t[1]}, 3 ≥ ${t[2]}, 4 ≥ ${t[3]}). Нажмите «+», чтобы изменить."
        } else {
            tvCustomScaleSummary.text = "Нажмите «+», чтобы задать свою шкалу делений"
        }
    }

    private fun showCustomScaleDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_custom_scale, null)
        val et1 = dialogView.findViewById<TextInputEditText>(R.id.etBar1)
        val et2 = dialogView.findViewById<TextInputEditText>(R.id.etBar2)
        val et3 = dialogView.findViewById<TextInputEditText>(R.id.etBar3)
        val et4 = dialogView.findViewById<TextInputEditText>(R.id.etBar4)

        val current = Prefs.getCustomThresholds(this)
        et1.setText(current[0].toString())
        et2.setText(current[1].toString())
        et3.setText(current[2].toString())
        et4.setText(current[3].toString())

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Своя шкала делений (dBm)")
            .setView(dialogView)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val v1 = et1.text?.toString()?.trim()?.toIntOrNull()
                val v2 = et2.text?.toString()?.trim()?.toIntOrNull()
                val v3 = et3.text?.toString()?.trim()?.toIntOrNull()
                val v4 = et4.text?.toString()?.trim()?.toIntOrNull()

                if (v1 == null || v2 == null || v3 == null || v4 == null) {
                    Toast.makeText(this, "Введите целые числа dBm во все 4 поля", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (v1 !in -160..-30 || v2 !in -160..-30 || v3 !in -160..-30 || v4 !in -160..-30) {
                    Toast.makeText(this, "Значения должны быть в диапазоне от -160 до -30 dBm", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (!(v1 <= v2 && v2 <= v3 && v3 <= v4)) {
                    Toast.makeText(this, "Пороги должны идти по возрастанию: 1 дел. ≤ 2 ≤ 3 ≤ 4", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                Prefs.setCustomThresholds(this, v1, v2, v3, v4)
                Prefs.setScale(this, Prefs.SCALE_CUSTOM)
                rgScale.clearCheck()
                refreshCustomScaleUi()
        updateScaleSectionVisibility()
                updateUiCard()
                refreshIfRunning()
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        uiHandler.post(uiTicker)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isEmpty()) {
            startMonitorService()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startMonitorService() {
        val intent = Intent(this, SignalMonitorService::class.java)
        startForegroundService(intent)
        updateUiCard()
    }

    private fun refreshIfRunning() {
        if (SignalState.isRunning) {
            val intent = Intent(this, SignalMonitorService::class.java).apply {
                action = SignalMonitorService.ACTION_REFRESH
            }
            startForegroundService(intent)
        }
    }

    private fun updateUiCard() {
        if (!SignalState.isRunning) {
            tvStatusBadge.text = "● Сервис остановлен"
            tvDbmValue.text = "-- dBm"
            tvDetails.text = "Нажмите «Запустить», чтобы вывести значок в статус-бар"
            return
        }

        val showBarsInfo = Prefs.getIconMode(this) == Prefs.MODE_BARS || Prefs.isShowBarsInDbmMode(this)
        val scaleName = Prefs.getScaleShortLabel(this)

        tvStatusBadge.text = "● Мониторинг активен"
        if (SignalState.isDualMode) {
            val activeSlot = SignalState.activeDataSlotIndex
            val p1 = if (activeSlot == 0) "•" else ""
            val p2 = if (activeSlot == 1) "•" else ""
            val s1 = SignalState.sim1Dbm?.let { "$p1$it" } ?: "$p1--"
            val s2 = SignalState.sim2Dbm?.let { "$p2$it" } ?: "$p2--"
            tvDbmValue.text = "$s1 / $s2 dBm"
            tvDetails.text = if (showBarsInfo) {
                "SIM1: ${SignalState.sim1Tech} (${SignalState.sim1Bars}/4 дел.) • SIM2: ${SignalState.sim2Tech} (${SignalState.sim2Bars}/4 дел.) • $scaleName"
            } else {
                "SIM1: ${SignalState.sim1Tech} • SIM2: ${SignalState.sim2Tech}"
            }
        } else {
            val dbm = SignalState.currentDbm
            tvDbmValue.text = if (dbm != null) "$dbm dBm" else "-- dBm"
            tvDetails.text = if (showBarsInfo) {
                "${SignalState.simLabel} • ${SignalState.networkLabel} • ${SignalState.currentBars}/4 дел. ($scaleName)"
            } else {
                "${SignalState.simLabel} • ${SignalState.networkLabel}"
            }
        }
    }
}
