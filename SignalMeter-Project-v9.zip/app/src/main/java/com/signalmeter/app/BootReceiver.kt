package com.signalmeter.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            Prefs.isAutostart(context) &&
            Prefs.isServiceEnabled(context)
        ) {
            try {
                val serviceIntent = Intent(context, SignalMonitorService::class.java)
                context.startForegroundService(serviceIntent)
            } catch (_: Exception) {
                // On strict Android 15+ power profiles, user may need to disable battery optimization
            }
        }
    }
}
