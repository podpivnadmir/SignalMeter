package com.signalmeter.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs

object IconRenderer {

    private const val SIZE = 96

    fun renderDbmIcon(dbm: Int?, showDataDot: Boolean = false): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val text = if (dbm != null) abs(dbm).toString() else "--"
        val isThreeDigits = text.length >= 3
        val textSizeVal = if (showDataDot) {
            if (isThreeDigits) 50f else 62f
        } else {
            if (isThreeDigits) 60f else 70f
        }
        val scaleXVal = if (showDataDot) {
            if (isThreeDigits) 0.76f else 0.90f
        } else {
            if (isThreeDigits) 0.78f else 0.95f
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            textSize = textSizeVal
            textScaleX = scaleXVal
        }

        val textWidth = paint.measureText(text)
        val dotRadius = if (showDataDot) 6.5f else 0f
        val dotGap = if (showDataDot) 8f else 0f
        val groupWidth = if (showDataDot) (dotRadius * 2f + dotGap + textWidth) else textWidth
        val groupStartX = ((SIZE - groupWidth) / 2f).coerceAtLeast(2f)

        val fm = paint.fontMetrics
        val y = (SIZE / 2f) - (fm.ascent + fm.descent) / 2f

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            val dotCx = groupStartX + dotRadius
            canvas.drawCircle(dotCx, SIZE / 2f, dotRadius, dotPaint)
            canvas.drawText(text, groupStartX + dotRadius * 2f + dotGap, y, paint)
        } else {
            canvas.drawText(text, groupStartX, y, paint)
        }

        return bitmap
    }

    fun renderDualDbmIcon(
        dbm1: Int?,
        dbm2: Int?,
        activeDataSlotIndex: Int? = null
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val topText = if (dbm1 != null) abs(dbm1).toString() else "--"
        val botText = if (dbm2 != null) abs(dbm2).toString() else "--"

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            textSize = 40f
            textScaleX = 0.84f
        }

        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        val fm = paint.fontMetrics
        val lineHeight = (fm.descent - fm.ascent) * 0.94f
        val centerY = SIZE / 2f

        val topCenterY = centerY - lineHeight / 2f
        val botCenterY = centerY + lineHeight / 2f
        val topBaseline = topCenterY - (fm.ascent + fm.descent) / 2f
        val botBaseline = botCenterY - (fm.ascent + fm.descent) / 2f

        drawRowWithOptionalDot(
            canvas = canvas,
            text = topText,
            centerY = topCenterY,
            baselineY = topBaseline,
            showDot = activeDataSlotIndex == 0,
            textPaint = paint,
            dotPaint = dotPaint
        )

        drawRowWithOptionalDot(
            canvas = canvas,
            text = botText,
            centerY = botCenterY,
            baselineY = botBaseline,
            showDot = activeDataSlotIndex == 1,
            textPaint = paint,
            dotPaint = dotPaint
        )

        return bitmap
    }

    private fun drawRowWithOptionalDot(
        canvas: Canvas,
        text: String,
        centerY: Float,
        baselineY: Float,
        showDot: Boolean,
        textPaint: Paint,
        dotPaint: Paint
    ) {
        val textWidth = textPaint.measureText(text)
        val dotRadius = if (showDot) 5.2f else 0f
        val dotGap = if (showDot) 6f else 0f
        val groupWidth = if (showDot) (dotRadius * 2f + dotGap + textWidth) else textWidth
        val startX = ((SIZE - groupWidth) / 2f).coerceAtLeast(2f)

        if (showDot) {
            canvas.drawCircle(startX + dotRadius, centerY, dotRadius, dotPaint)
            canvas.drawText(text, startX + dotRadius * 2f + dotGap, baselineY, textPaint)
        } else {
            canvas.drawText(text, startX, baselineY, textPaint)
        }
    }

    fun renderBarsIcon(bars: Int, showDataDot: Boolean = false): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(75, 255, 255, 255)
            style = Paint.Style.FILL
        }

        val barWidth = 14f
        val gap = 6f
        val totalWidth = barWidth * 4 + gap * 3
        val dotSpace = if (showDataDot) 16f else 0f
        val startX = (((SIZE - (totalWidth + dotSpace)) / 2f) + dotSpace).coerceAtLeast(18f)
        val bottomY = SIZE - 12f
        val heights = floatArrayOf(22f, 38f, 54f, 72f)
        val radius = 5f

        for (i in 0 until 4) {
            val left = startX + i * (barWidth + gap)
            val top = bottomY - heights[i]
            val rect = RectF(left, top, left + barWidth, bottomY)
            val paint = if (i < bars) activePaint else inactivePaint
            canvas.drawRoundRect(rect, radius, radius, paint)
        }

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(9f, bottomY - 6f, 6f, dotPaint)
        }

        if (bars == 0) {
            val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                strokeWidth = 7f
                strokeCap = Paint.Cap.ROUND
            }
            canvas.drawLine(startX, 16f, startX + 20f, 36f, xPaint)
            canvas.drawLine(startX + 20f, 16f, startX, 36f, xPaint)
        }

        return bitmap
    }

    fun renderDualBarsIcon(
        bars1: Int,
        bars2: Int,
        activeDataSlotIndex: Int? = null
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawCompactBarRow(canvas, bars1, topY = 4f, height = 38f, showDot = activeDataSlotIndex == 0)
        drawCompactBarRow(canvas, bars2, topY = 54f, height = 38f, showDot = activeDataSlotIndex == 1)

        return bitmap
    }

    private fun drawCompactBarRow(
        canvas: Canvas,
        bars: Int,
        topY: Float,
        height: Float,
        showDot: Boolean = false
    ) {
        val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(75, 255, 255, 255)
            style = Paint.Style.FILL
        }

        val barWidth = 14f
        val gap = 6f
        val totalWidth = barWidth * 4 + gap * 3
        val startX = ((SIZE - totalWidth) / 2f) + (if (showDot) 4f else 0f)
        val bottomY = topY + height
        val ratios = floatArrayOf(0.32f, 0.54f, 0.77f, 1.0f)

        for (i in 0 until 4) {
            val barH = height * ratios[i]
            val left = startX + i * (barWidth + gap)
            val top = bottomY - barH
            val rect = RectF(left, top, left + barWidth, bottomY)
            canvas.drawRoundRect(rect, 4f, 4f, if (i < bars) activePaint else inactivePaint)
        }

        if (showDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(7f, bottomY - 5f, 4.8f, dotPaint)
        }
    }
}
