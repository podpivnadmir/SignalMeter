package com.signalmeter.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telephony.CellInfo
import android.telephony.CellSignalStrengthGsm
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.CellSignalStrengthWcdma
import android.telephony.SignalStrength
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager

class SignalMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "signal_meter_status_v1"
        const val NOTIFICATION_ID = 1001
        const val ACTION_REFRESH = "com.signalmeter.app.ACTION_REFRESH"
        const val ACTION_STOP = "com.signalmeter.app.ACTION_STOP"
        private const val POLL_INTERVAL_MS = 5000L
    }

    private data class SimSlotState(
        val slotIndex: Int,
        var subId: Int = SubscriptionManager.INVALID_SUBSCRIPTION_ID,
        var carrierName: String,
        var tm: TelephonyManager? = null,
        var callback: SlotTelephonyCallback? = null,
        var lastSignalStrength: SignalStrength? = null,
        var lastDisplayInfo: TelephonyDisplayInfo? = null,
        var dbm: Int? = null,
        var bars: Int = 0,
        var tech: String = "Нет сети",
        var hasRealNr: Boolean = false
    )

    private lateinit var notificationManager: NotificationManager
    private lateinit var powerManager: PowerManager

    private val slot1 = SimSlotState(slotIndex = 0, carrierName = "SIM 1")
    private val slot2 = SimSlotState(slotIndex = 1, carrierName = "SIM 2")

    // Single-SIM mode fields
    private var activeTelephonyManager: TelephonyManager? = null
    private var telephonyCallback: SingleTelephonyCallback? = null
    private var lastDisplayInfo: TelephonyDisplayInfo? = null
    private var lastSignalStrength: SignalStrength? = null
    private var currentSubId: Int = SubscriptionManager.INVALID_SUBSCRIPTION_ID

    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (SignalState.isRunning) {
                if (powerManager.isInteractive) {
                    checkSubscriptionAndPoll()
                }
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setServiceEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }

        SignalState.isRunning = true
        Prefs.setServiceEnabled(this, true)

        val initialNotification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        setupListeners(forceReset = true)
        handler.removeCallbacks(pollRunnable)
        handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)

        return START_STICKY
    }

    override fun onDestroy() {
        SignalState.isRunning = false
        handler.removeCallbacks(pollRunnable)
        unregisterAllListeners()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Уровень сигнала (dBm / деления)",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Постоянный индикатор реального уровня сигнала в статус-баре"
            setSound(null, null)
            enableVibration(false)
            enableLights(false)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        notificationManager.createNotificationChannel(channel)
    }

    private fun resolveActiveDataSlotIndex(subs: List<SubscriptionInfo>): Int? {
        val dataSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        if (dataSubId == SubscriptionManager.INVALID_SUBSCRIPTION_ID) return null
        return subs.firstOrNull { it.subscriptionId == dataSubId }?.simSlotIndex
    }

    private fun isCurrentSlotProvidingData(): Boolean {
        val subs = getActiveSubs()
        val activeSlot = resolveActiveDataSlotIndex(subs)
        SignalState.activeDataSlotIndex = activeSlot
        if (activeSlot == null) return false

        val slotPref = Prefs.getSimSlot(this)
        return when (slotPref) {
            Prefs.SIM_1 -> activeSlot == 0
            Prefs.SIM_2 -> activeSlot == 1
            Prefs.SIM_AUTO -> {
                val targetSlot = subs.firstOrNull { it.subscriptionId == currentSubId }?.simSlotIndex
                targetSlot == activeSlot
            }
            else -> false
        }
    }

    private fun getActiveSubs(): List<SubscriptionInfo> {
        val subManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        return try {
            subManager.activeSubscriptionInfoList ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    private fun resolveTargetSubId(subs: List<SubscriptionInfo>): Pair<Int, String> {
        val slotPref = Prefs.getSimSlot(this)

        if (slotPref == Prefs.SIM_1 || slotPref == Prefs.SIM_2) {
            val targetSlotIndex = if (slotPref == Prefs.SIM_1) 0 else 1
            val found = subs.firstOrNull { it.simSlotIndex == targetSlotIndex }
            if (found != null) {
                val carrier = found.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM ${targetSlotIndex + 1}"
                return Pair(found.subscriptionId, carrier)
            }
        }

        val dataSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        if (dataSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            val found = subs.firstOrNull { it.subscriptionId == dataSubId }
            val carrier = found?.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM"
            return Pair(dataSubId, carrier)
        }

        val first = subs.firstOrNull()
        if (first != null) {
            val carrier = first.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM 1"
            return Pair(first.subscriptionId, carrier)
        }

        return Pair(SubscriptionManager.INVALID_SUBSCRIPTION_ID, "SIM")
    }

    private fun setupListeners(forceReset: Boolean) {
        val isDual = Prefs.getSimSlot(this) == Prefs.SIM_BOTH
        SignalState.isDualMode = isDual

        if (isDual) {
            unregisterSingleListener()
            currentSubId = SubscriptionManager.INVALID_SUBSCRIPTION_ID
            setupDualSlotListeners(forceReset)
        } else {
            unregisterDualListeners()
            setupSingleListener(forceReset)
        }
    }

    private fun setupSingleListener(forceReset: Boolean) {
        val subs = getActiveSubs()
        val (targetSubId, simName) = resolveTargetSubId(subs)
        SignalState.simLabel = simName

        if (!forceReset && targetSubId == currentSubId && telephonyCallback != null) {
            recomputeSingleAndNotify()
            return
        }

        unregisterSingleListener()
        currentSubId = targetSubId

        val baseTm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val tm = if (targetSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            baseTm.createForSubscriptionId(targetSubId)
        } else {
            baseTm
        }
        activeTelephonyManager = tm

        val cb = SingleTelephonyCallback()
        telephonyCallback = cb
        try {
            tm.registerTelephonyCallback(mainExecutor, cb)
        } catch (_: SecurityException) {
            SignalState.networkLabel = "Нет разрешения «Телефон»"
            updateNotification()
            return
        }

        tm.signalStrength?.let {
            lastSignalStrength = it
        }
        recomputeSingleAndNotify()
    }

    private fun setupDualSlotListeners(forceReset: Boolean) {
        val subs = getActiveSubs()
        val baseTm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        for (slot in listOf(slot1, slot2)) {
            val info = subs.firstOrNull { it.simSlotIndex == slot.slotIndex }
            val newSubId = info?.subscriptionId ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID
            slot.carrierName = info?.carrierName?.toString()?.takeIf { it.isNotBlank() }
                ?: "SIM ${slot.slotIndex + 1}"

            if (!forceReset && newSubId == slot.subId && slot.callback != null) {
                slot.lastSignalStrength = slot.tm?.signalStrength ?: slot.lastSignalStrength
                evaluateSlot(slot)
                continue
            }

            unregisterSlotListener(slot)
            slot.subId = newSubId
            slot.lastSignalStrength = null
            slot.lastDisplayInfo = null

            if (newSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                val tm = baseTm.createForSubscriptionId(newSubId)
                val cb = SlotTelephonyCallback(slot)
                slot.tm = tm
                slot.callback = cb
                try {
                    tm.registerTelephonyCallback(mainExecutor, cb)
                    tm.signalStrength?.let { slot.lastSignalStrength = it }
                } catch (_: SecurityException) {
                    slot.dbm = null
                    slot.bars = 0
                    slot.tech = "Нет прав"
                }
            } else {
                slot.tm = null
                slot.callback = null
                slot.dbm = null
                slot.bars = 0
                slot.tech = "Не активна"
            }
            evaluateSlot(slot)
        }

        syncDualState()
        updateNotification()
    }

    private fun checkSubscriptionAndPoll() {
        val isDual = Prefs.getSimSlot(this) == Prefs.SIM_BOTH
        if (isDual != SignalState.isDualMode) {
            setupListeners(forceReset = true)
            return
        }

        if (isDual) {
            val subs = getActiveSubs()
            val sub1Now = subs.firstOrNull { it.simSlotIndex == 0 }?.subscriptionId
                ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID
            val sub2Now = subs.firstOrNull { it.simSlotIndex == 1 }?.subscriptionId
                ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID

            if (sub1Now != slot1.subId || sub2Now != slot2.subId) {
                setupDualSlotListeners(forceReset = true)
                return
            }

            slot1.tm?.signalStrength?.let {
                slot1.lastSignalStrength = it
                evaluateSlot(slot1)
            }
            slot2.tm?.signalStrength?.let {
                slot2.lastSignalStrength = it
                evaluateSlot(slot2)
            }
            syncDualState()
            updateNotification()
        } else {
            val subs = getActiveSubs()
            val (targetSubId, simName) = resolveTargetSubId(subs)
            SignalState.simLabel = simName
            if (targetSubId != currentSubId) {
                setupSingleListener(forceReset = true)
                return
            }
            activeTelephonyManager?.signalStrength?.let {
                lastSignalStrength = it
                recomputeSingleAndNotify()
            }
        }
    }

    private fun unregisterSingleListener() {
        val cb = telephonyCallback
        val tm = activeTelephonyManager
        if (cb != null && tm != null) {
            try {
                tm.unregisterTelephonyCallback(cb)
            } catch (_: Exception) {
            }
        }
        telephonyCallback = null
        activeTelephonyManager = null
    }

    private fun unregisterSlotListener(slot: SimSlotState) {
        val cb = slot.callback
        val tm = slot.tm
        if (cb != null && tm != null) {
            try {
                tm.unregisterTelephonyCallback(cb)
            } catch (_: Exception) {
            }
        }
        slot.callback = null
        slot.tm = null
    }

    private fun unregisterDualListeners() {
        unregisterSlotListener(slot1)
        unregisterSlotListener(slot2)
    }

    private fun unregisterAllListeners() {
        unregisterSingleListener()
        unregisterDualListeners()
    }

    private inner class SingleTelephonyCallback :
        TelephonyCallback(),
        TelephonyCallback.SignalStrengthsListener,
        TelephonyCallback.DisplayInfoListener {

        override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
            lastSignalStrength = signalStrength
            recomputeSingleAndNotify()
        }

        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
            lastDisplayInfo = telephonyDisplayInfo
            recomputeSingleAndNotify()
        }
    }

    private inner class SlotTelephonyCallback(private val slot: SimSlotState) :
        TelephonyCallback(),
        TelephonyCallback.SignalStrengthsListener,
        TelephonyCallback.DisplayInfoListener {

        override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
            slot.lastSignalStrength = signalStrength
            evaluateSlot(slot)
            syncDualState()
            updateNotification()
        }

        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
            slot.lastDisplayInfo = telephonyDisplayInfo
            evaluateSlot(slot)
            syncDualState()
            updateNotification()
        }
    }

    private fun parseStrength(
        strength: SignalStrength?,
        displayInfo: TelephonyDisplayInfo?
    ): Triple<Int?, String, Boolean> {
        var dbm: Int? = null
        var hasRealNr = false
        var detectedTech = "Нет сети"

        if (strength != null) {
            val nrList = strength.getCellSignalStrengths(CellSignalStrengthNr::class.java)
            val lteList = strength.getCellSignalStrengths(CellSignalStrengthLte::class.java)
            val wcdmaList = strength.getCellSignalStrengths(CellSignalStrengthWcdma::class.java)
            val gsmList = strength.getCellSignalStrengths(CellSignalStrengthGsm::class.java)

            val nrRsrp = nrList.firstOrNull()?.ssRsrp?.takeIf { isValidDbm(it) }
            val lteRsrp = lteList.firstOrNull()?.rsrp?.takeIf { isValidDbm(it) }
            val wcdmaDbm = wcdmaList.firstOrNull()?.dbm?.takeIf { isValidDbm(it) }
            val gsmDbm = gsmList.firstOrNull()?.dbm?.takeIf { isValidDbm(it) }

            when {
                nrRsrp != null -> {
                    dbm = nrRsrp
                    hasRealNr = true
                    detectedTech = "5G NR"
                }
                lteRsrp != null -> {
                    dbm = lteRsrp
                    detectedTech = "LTE"
                }
                wcdmaDbm != null -> {
                    dbm = wcdmaDbm
                    detectedTech = "3G"
                }
                gsmDbm != null -> {
                    dbm = gsmDbm
                    detectedTech = "2G / E"
                }
            }
        }

        if (displayInfo != null) {
            detectedTech = formatNetworkType(displayInfo, hasRealNr, detectedTech)
        }

        return Triple(dbm, detectedTech, hasRealNr)
    }

    private fun evaluateSlot(slot: SimSlotState) {
        if (slot.subId == SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            slot.dbm = null
            slot.bars = 0
            slot.tech = "Не активна"
            slot.hasRealNr = false
            return
        }
        val (dbm, tech, realNr) = parseStrength(slot.lastSignalStrength, slot.lastDisplayInfo)
        slot.dbm = dbm
        slot.tech = tech
        slot.hasRealNr = realNr
        slot.bars = Prefs.calculateBars(dbm, this)
    }

    private fun syncDualState() {
        SignalState.isDualMode = true
        SignalState.activeDataSlotIndex = resolveActiveDataSlotIndex(getActiveSubs())
        SignalState.sim1Name = slot1.carrierName
        SignalState.sim2Name = slot2.carrierName
        SignalState.sim1Dbm = slot1.dbm
        SignalState.sim2Dbm = slot2.dbm
        SignalState.sim1Bars = slot1.bars
        SignalState.sim2Bars = slot2.bars
        SignalState.sim1Tech = slot1.tech
        SignalState.sim2Tech = slot2.tech

        SignalState.currentDbm = slot1.dbm ?: slot2.dbm
        SignalState.currentBars = if (slot1.dbm != null) slot1.bars else slot2.bars
        SignalState.networkLabel = "${slot1.tech} / ${slot2.tech}"
        SignalState.simLabel = "${slot1.carrierName} + ${slot2.carrierName}"
        SignalState.isReal5g = slot1.hasRealNr || slot2.hasRealNr
    }

    private fun recomputeSingleAndNotify() {
        SignalState.isDualMode = false
        SignalState.activeDataSlotIndex = resolveActiveDataSlotIndex(getActiveSubs())
        val (dbm, detectedTech, hasRealNr) = parseStrength(lastSignalStrength, lastDisplayInfo)
        val bars = Prefs.calculateBars(dbm, this)

        SignalState.currentDbm = dbm
        SignalState.currentBars = bars
        SignalState.networkLabel = detectedTech
        SignalState.isReal5g = hasRealNr

        updateNotification()
    }

    private fun isValidDbm(value: Int): Boolean {
        return value != CellInfo.UNAVAILABLE && value in -150..-30
    }

    private fun formatNetworkType(
        info: TelephonyDisplayInfo,
        hasRealNr: Boolean,
        fallback: String
    ): String {
        return when (info.overrideNetworkType) {
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED ->
                if (hasRealNr) "5G+" else "LTE+ (метка 5G)"
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA ->
                if (hasRealNr) "5G NSA" else "LTE (метка 5G)"
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_ADVANCED_PRO,
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_CA -> "LTE+"
            else -> when (info.networkType) {
                TelephonyManager.NETWORK_TYPE_NR -> "5G SA"
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                TelephonyManager.NETWORK_TYPE_HSPAP,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
                TelephonyManager.NETWORK_TYPE_EDGE -> "E"
                TelephonyManager.NETWORK_TYPE_GPRS -> "G"
                else -> fallback
            }
        }
    }

    private fun buildNotification(): Notification {
        val iconMode = Prefs.getIconMode(this)
        val isDual = Prefs.getSimSlot(this) == Prefs.SIM_BOTH
        val showBarsInfo = iconMode == Prefs.MODE_BARS || Prefs.isShowBarsInDbmMode(this)
        val scaleName = Prefs.getScaleShortLabel(this)

        val bitmap: Bitmap
        val title: String
        val subtitle: String

        if (isDual) {
            val d1 = SignalState.sim1Dbm
            val d2 = SignalState.sim2Dbm
            val b1 = SignalState.sim1Bars
            val b2 = SignalState.sim2Bars
            val activeDataSlot = SignalState.activeDataSlotIndex

            bitmap = if (iconMode == Prefs.MODE_BARS) {
                IconRenderer.renderDualBarsIcon(b1, b2, activeDataSlot)
            } else {
                IconRenderer.renderDualDbmIcon(d1, d2, activeDataSlot)
            }

            val m1 = if (activeDataSlot == 0) "•" else ""
            val m2 = if (activeDataSlot == 1) "•" else ""
            val s1Text = d1?.let { "$it dBm" } ?: "--"
            val s2Text = d2?.let { "$it dBm" } ?: "--"
            title = "$m1${"SIM1"}: $s1Text  |  $m2${"SIM2"}: $s2Text"
            subtitle = if (showBarsInfo) {
                "${SignalState.sim1Name} (${SignalState.sim1Tech}, $b1/4 дел.)  •  ${SignalState.sim2Name} (${SignalState.sim2Tech}, $b2/4 дел.)"
            } else {
                "${SignalState.sim1Name} (${SignalState.sim1Tech})  •  ${SignalState.sim2Name} (${SignalState.sim2Tech})"
            }
        } else {
            val dbm = SignalState.currentDbm
            val bars = SignalState.currentBars
            val isDataSim = isCurrentSlotProvidingData()

            bitmap = if (iconMode == Prefs.MODE_BARS) {
                IconRenderer.renderBarsIcon(bars, isDataSim)
            } else {
                IconRenderer.renderDbmIcon(dbm, isDataSim)
            }

            val prefix = if (isDataSim) "• " else ""
            val dbmText = if (dbm != null) "$dbm dBm" else "-- dBm"
            title = "$prefix$dbmText  •  ${SignalState.networkLabel}"
            subtitle = if (showBarsInfo) {
                "${SignalState.simLabel}  •  $bars/4 дел. ($scaleName)"
            } else {
                SignalState.simLabel
            }
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(Icon.createWithBitmap(bitmap))
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(pendingIntent)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .build()
    }

    private fun updateNotification() {
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification())
        } catch (_: SecurityException) {
        }
    }
}
