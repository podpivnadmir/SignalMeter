package com.signalmeter.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs

object IconRenderer {

    private const val SIZE = 96

    fun renderDbmIcon(dbm: Int?): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val text = if (dbm != null) abs(dbm).toString() else "--"
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            if (text.length >= 3) {
                textSize = 60f
                textScaleX = 0.78f
            } else {
                textSize = 70f
                textScaleX = 0.95f
            }
        }

        val fm = paint.fontMetrics
        val y = (SIZE / 2f) - (fm.ascent + fm.descent) / 2f
        canvas.drawText(text, SIZE / 2f, y, paint)

        return bitmap
    }

    fun renderBarsIcon(bars: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(75, 255, 255, 255)
            style = Paint.Style.FILL
        }

        val barWidth = 15f
        val gap = 7f
        val totalWidth = barWidth * 4 + gap * 3
        val startX = (SIZE - totalWidth) / 2f
        val bottomY = SIZE - 12f
        val heights = floatArrayOf(22f, 38f, 54f, 72f)
        val radius = 5f

        for (i in 0 until 4) {
            val left = startX + i * (barWidth + gap)
            val top = bottomY - heights[i]
            val rect = RectF(left, top, left + barWidth, bottomY)
            val paint = if (i < bars) activePaint else inactivePaint
            canvas.drawRoundRect(rect, radius, radius, paint)
        }

        if (bars == 0) {
            val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                strokeWidth = 7f
                strokeCap = Paint.Cap.ROUND
            }
            canvas.drawLine(14f, 16f, 34f, 36f, xPaint)
            canvas.drawLine(34f, 16f, 14f, 36f, xPaint)
        }

        return bitmap
    }
}
