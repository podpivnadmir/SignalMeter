package com.signalmeter.app

object SignalState {
    @Volatile
    var isRunning: Boolean = false

    @Volatile
    var currentDbm: Int? = null

    @Volatile
    var currentBars: Int = 0

    @Volatile
    var networkLabel: String = "Ожидание..."

    @Volatile
    var simLabel: String = "SIM"

    @Volatile
    var isReal5g: Boolean = false
}
