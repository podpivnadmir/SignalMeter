package com.signalmeter.app

import android.content.Context

object Prefs {
    private const val PREFS_NAME = "signal_meter_prefs"

    const val MODE_DBM = 0
    const val MODE_BARS = 1

    const val SCALE_STRICT = 0 // -115, -105, -95, -85
    const val SCALE_SOFT = 1   // -120, -110, -100, -90
    const val SCALE_CUSTOM = 2 // user-defined 4 thresholds

    const val SIM_AUTO = 0
    const val SIM_1 = 1
    const val SIM_2 = 2
    const val SIM_BOTH = 3

    val DEFAULT_CUSTOM_THRESHOLDS = intArrayOf(-115, -105, -95, -85)

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isShowStatusBarIcon(ctx: Context): Boolean = prefs(ctx).getBoolean("show_status_bar_icon", true)
    fun setShowStatusBarIcon(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("show_status_bar_icon", enabled).apply()

    fun isShowTechBadgeOnIcon(ctx: Context): Boolean = prefs(ctx).getBoolean("show_tech_badge_on_icon", true)
    fun setShowTechBadgeOnIcon(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("show_tech_badge_on_icon", enabled).apply()

    fun getIconMode(ctx: Context): Int = prefs(ctx).getInt("icon_mode", MODE_DBM)
    fun setIconMode(ctx: Context, mode: Int) = prefs(ctx).edit().putInt("icon_mode", mode).apply()

    fun isShowBarsInDbmMode(ctx: Context): Boolean = prefs(ctx).getBoolean("show_bars_in_dbm_mode", true)
    fun setShowBarsInDbmMode(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("show_bars_in_dbm_mode", enabled).apply()

    fun getScale(ctx: Context): Int = prefs(ctx).getInt("scale", SCALE_STRICT)
    fun setScale(ctx: Context, scale: Int) = prefs(ctx).edit().putInt("scale", scale).apply()

    fun hasCustomThresholds(ctx: Context): Boolean = prefs(ctx).getBoolean("has_custom_scale", false)

    fun getCustomThresholds(ctx: Context): IntArray {
        val p = prefs(ctx)
        return intArrayOf(
            p.getInt("custom_t1", DEFAULT_CUSTOM_THRESHOLDS[0]),
            p.getInt("custom_t2", DEFAULT_CUSTOM_THRESHOLDS[1]),
            p.getInt("custom_t3", DEFAULT_CUSTOM_THRESHOLDS[2]),
            p.getInt("custom_t4", DEFAULT_CUSTOM_THRESHOLDS[3])
        )
    }

    fun setCustomThresholds(ctx: Context, t1: Int, t2: Int, t3: Int, t4: Int) {
        prefs(ctx).edit()
            .putBoolean("has_custom_scale", true)
            .putInt("custom_t1", t1)
            .putInt("custom_t2", t2)
            .putInt("custom_t3", t3)
            .putInt("custom_t4", t4)
            .apply()
    }

    fun formatThresholds(thresholds: IntArray): String {
        return "${thresholds[0]} / ${thresholds[1]} / ${thresholds[2]} / ${thresholds[3]} dBm"
    }

    fun getScaleShortLabel(ctx: Context): String {
        return when (getScale(ctx)) {
            SCALE_SOFT -> "мягкая"
            SCALE_CUSTOM -> "своя (${formatThresholds(getCustomThresholds(ctx))})"
            else -> "строгая"
        }
    }

    fun getSimSlot(ctx: Context): Int = prefs(ctx).getInt("sim_slot", SIM_AUTO)
    fun setSimSlot(ctx: Context, slot: Int) = prefs(ctx).edit().putInt("sim_slot", slot).apply()

    fun isAutostart(ctx: Context): Boolean = prefs(ctx).getBoolean("autostart", true)
    fun setAutostart(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("autostart", enabled).apply()

    fun isServiceEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("service_enabled", false)
    fun setServiceEnabled(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("service_enabled", enabled).apply()

    fun calculateBars(dbm: Int?, ctx: Context): Int {
        if (dbm == null) return 0
        val thresholds = when (getScale(ctx)) {
            SCALE_SOFT -> intArrayOf(-120, -110, -100, -90)
            SCALE_CUSTOM -> getCustomThresholds(ctx)
            else -> intArrayOf(-115, -105, -95, -85)
        }
        return when {
            dbm >= thresholds[3] -> 4
            dbm >= thresholds[2] -> 3
            dbm >= thresholds[1] -> 2
            dbm >= thresholds[0] -> 1
            else -> 0
        }
    }
}
