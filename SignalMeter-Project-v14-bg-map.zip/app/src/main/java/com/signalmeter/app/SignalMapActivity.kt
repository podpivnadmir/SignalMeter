package com.signalmeter.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SignalMapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var tvMapLiveDbm: TextView
    private lateinit var tvMapPointsCount: TextView
    private lateinit var tvMapStatus: TextView

    private lateinit var locationManager: LocationManager
    private var lastLocation: Location? = null
    private var lastRecordedLocation: Location? = null
    private var lastRecordedDbm: Int? = null
    private var lastRecordedTimeMs: Long = 0L
    private var centeredOnce = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateHeaderAndMaybeRecord()
            uiHandler.postDelayed(this, 1500L)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLocation = location
            if (!centeredOnce) {
                centeredOnce = true
                mapView.controller.animateTo(GeoPoint(location.latitude, location.longitude))
            }
            recordPointIfNeeded(location, force = false)
            updateHeader()
        }

        @Deprecated("Deprecated in Android")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        startLocationUpdates()
        updateHeader()
    }

    private val createJsonLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            val json = SignalMapStore.exportToJsonString(this)
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(json.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, "Карта замеров сохранена", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val openJsonLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            val content = contentResolver.openInputStream(uri)?.use { inp ->
                inp.bufferedReader(Charsets.UTF_8).readText()
            }.orEmpty()
            val count = SignalMapStore.importFromJsonString(this, content, merge = true)
            if (count > 0) {
                renderAllPoints()
                updateHeader()
                Toast.makeText(this, "Загружено точек: $count", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "В файле не найдено точек замеров", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка открытия файла: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        Configuration.getInstance().osmdroidBasePath = filesDir.resolve("osmdroid")
        Configuration.getInstance().osmdroidTileCache = cacheDir.resolve("osmdroid_tiles")

        setContentView(R.layout.activity_signal_map)
        supportActionBar?.title = "Карта dBm"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        tvMapLiveDbm = findViewById(R.id.tvMapLiveDbm)
        tvMapPointsCount = findViewById(R.id.tvMapPointsCount)
        tvMapStatus = findViewById(R.id.tvMapStatus)
        mapView = findViewById(R.id.osmMapView)

        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(17.5)
        mapView.controller.setCenter(GeoPoint(55.9105, 37.7365))

        findViewById<MaterialButton>(R.id.btnMarkHere).setOnClickListener {
            val loc = lastLocation ?: getBestLastKnownLocation()
            if (loc == null) {
                Toast.makeText(this, "Координаты ещё не получены", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lastLocation = loc
            recordPointIfNeeded(loc, force = true)
            updateHeader()
        }

        findViewById<MaterialButton>(R.id.btnCenterMap).setOnClickListener {
            val loc = lastLocation ?: getBestLastKnownLocation()
            if (loc != null) {
                lastLocation = loc
                mapView.controller.animateTo(GeoPoint(loc.latitude, loc.longitude))
                mapView.controller.setZoom(18.0)
            } else {
                Toast.makeText(this, "Ожидание GPS/сети...", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<MaterialButton>(R.id.btnExportPoints).setOnClickListener {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
            createJsonLauncher.launch("signal_map_$stamp.json")
        }

        findViewById<MaterialButton>(R.id.btnImportPoints).setOnClickListener {
            openJsonLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
        }

        findViewById<MaterialButton>(R.id.btnClearPoints).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Очистить карту?")
                .setMessage("Все сохранённые цветные точки dBm на карте будут удалены.")
                .setPositiveButton("Очистить") { _, _ ->
                    SignalMapStore.clearPoints(this)
                    lastRecordedLocation = null
                    lastRecordedDbm = null
                    renderAllPoints()
                    updateHeader()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        ensureLocationPermissionAndStart()
        renderAllPoints()
        updateHeader()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        renderAllPoints()
        ensureLocationPermissionAndStart()
        uiHandler.post(refreshRunnable)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(refreshRunnable)
        stopLocationUpdates()
        mapView.onPause()
        super.onPause()
    }

    private fun ensureLocationPermissionAndStart() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) {
            startLocationUpdates()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun startLocationUpdates() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return

        try {
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 2f, locationListener)
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 2f, locationListener)
            }
        } catch (_: SecurityException) {
        }

        val best = getBestLastKnownLocation()
        if (best != null) {
            lastLocation = best
            if (!centeredOnce) {
                centeredOnce = true
                mapView.controller.setCenter(GeoPoint(best.latitude, best.longitude))
            }
            recordPointIfNeeded(best, force = false)
        }
    }

    private fun stopLocationUpdates() {
        try {
            locationManager.removeUpdates(locationListener)
        } catch (_: Exception) {
        }
    }

    private fun getBestLastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null

        val providers = listOfNotNull(
            if (fine) LocationManager.GPS_PROVIDER else null,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        var best: Location? = null
        for (provider in providers) {
            try {
                val loc = locationManager.getLastKnownLocation(provider) ?: continue
                if (best == null || loc.time > best.time) {
                    best = loc
                }
            } catch (_: SecurityException) {
            }
        }
        return best
    }

    private fun currentDbmValue(): Int? {
        if (SignalState.isDualMode) {
            val active = SignalState.activeDataSlotIndex
            return when (active) {
                0 -> SignalState.sim1Dbm ?: SignalState.sim2Dbm
                1 -> SignalState.sim2Dbm ?: SignalState.sim1Dbm
                else -> SignalState.sim1Dbm ?: SignalState.sim2Dbm
            }
        }
        return SignalState.currentDbm
    }

    private fun currentTechLabel(): String {
        if (SignalState.isDualMode) {
            return when (SignalState.activeDataSlotIndex) {
                0 -> SignalState.sim1Tech
                1 -> SignalState.sim2Tech
                else -> SignalState.networkLabel
            }
        }
        return SignalState.networkLabel
    }

    private fun currentSimLabel(): String {
        if (SignalState.isDualMode) {
            return when (SignalState.activeDataSlotIndex) {
                0 -> "SIM1 (${SignalState.sim1Name})"
                1 -> "SIM2 (${SignalState.sim2Name})"
                else -> SignalState.simLabel
            }
        }
        return SignalState.simLabel
    }

    private fun updateHeaderAndMaybeRecord() {
        val loc = lastLocation ?: getBestLastKnownLocation()
        if (loc != null) {
            lastLocation = loc
            recordPointIfNeeded(loc, force = false)
        }
        updateHeader()
    }

    private fun recordPointIfNeeded(location: Location, force: Boolean) {
        val dbm = currentDbmValue() ?: return
        val now = System.currentTimeMillis()
        val prevLoc = lastRecordedLocation
        val movedMeters = if (prevLoc != null) location.distanceTo(prevLoc) else Float.MAX_VALUE
        val elapsedMs = now - lastRecordedTimeMs
        val dbmChanged = lastRecordedDbm == null || kotlin.math.abs(dbm - (lastRecordedDbm ?: dbm)) >= 3

        val shouldRecord = force ||
            prevLoc == null ||
            (movedMeters >= 4f && elapsedMs >= 1500L) ||
            (dbmChanged && elapsedMs >= 2000L) ||
            elapsedMs >= 6000L

        if (!shouldRecord) return

        val point = SignalMapPoint(
            id = now,
            lat = location.latitude,
            lon = location.longitude,
            dbm = dbm,
            tech = currentTechLabel(),
            simInfo = currentSimLabel(),
            accuracyMeters = location.accuracy,
            timestampMs = now
        )
        SignalMapStore.appendPoint(this, point)
        lastRecordedLocation = location
        lastRecordedDbm = dbm
        lastRecordedTimeMs = now
        addPointMarker(point)
        mapView.invalidate()
    }

    private fun renderAllPoints() {
        mapView.overlays.clear()
        val points = SignalMapStore.loadPoints(this)
        for (p in points) {
            addPointMarker(p)
        }
        if (points.isNotEmpty() && !centeredOnce && lastLocation == null) {
            val last = points.last()
            mapView.controller.setCenter(GeoPoint(last.lat, last.lon))
            centeredOnce = true
        }
        mapView.invalidate()
    }

    private fun addPointMarker(point: SignalMapPoint) {
        val marker = Marker(mapView).apply {
            position = GeoPoint(point.lat, point.lon)
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            icon = createColorDotDrawable(SignalMapStore.colorForDbm(point.dbm))
            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(point.timestampMs))
            title = "${point.dbm} dBm (${SignalMapStore.labelForDbm(point.dbm)}) • ${point.tech}"
            snippet = "${point.simInfo} • ±${point.accuracyMeters.toInt()} м • $timeStr"
        }
        mapView.overlays.add(marker)
    }

    private fun createColorDotDrawable(colorInt: Int): BitmapDrawable {
        val px = 34
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInt
            style = Paint.Style.FILL
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
        }
        val radius = px / 2f - 3f
        canvas.drawCircle(px / 2f, px / 2f, radius, fillPaint)
        canvas.drawCircle(px / 2f, px / 2f, radius, strokePaint)
        return BitmapDrawable(resources, bmp)
    }

    private fun updateHeader() {
        val dbm = currentDbmValue()
        val total = SignalMapStore.loadPoints(this).size
        tvMapPointsCount.text = "Точек: $total"

        if (dbm != null) {
            tvMapLiveDbm.text = "$dbm dBm"
            tvMapLiveDbm.setTextColor(SignalMapStore.colorForDbm(dbm))
        } else {
            tvMapLiveDbm.text = "-- dBm"
        }

        val loc = lastLocation
        val bgState = if (SignalState.isRunning) "фон вкл." else "запустите сервис для фона"
        tvMapStatus.text = if (loc != null) {
            val acc = if (loc.accuracy > 0f) "±${loc.accuracy.toInt()} м" else "координаты получены"
            "Карта обновляется • $bgState • $acc"
        } else {
            "Карта обновляется • $bgState • ожидание GPS/сети"
        }
    }
}
