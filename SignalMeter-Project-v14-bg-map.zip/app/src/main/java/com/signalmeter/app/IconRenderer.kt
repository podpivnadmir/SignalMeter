package com.signalmeter.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs

object IconRenderer {

    private const val SIZE = 96

    fun shortTechLabel(rawTech: String): String {
        val clean = rawTech.substringBefore(" (").trim()
        return when {
            clean.startsWith("5G+") -> "5G+"
            clean.startsWith("5G") -> "5G"
            clean == "LTE+" -> "4G+"
            clean == "LTE" -> "4G"
            clean == "3G" -> "3G"
            clean == "E" -> "E"
            clean == "G" -> "G"
            clean.startsWith("2G") -> "2G"
            else -> ""
        }
    }

    fun renderDbmIcon(
        dbm: Int?,
        showDataDot: Boolean = false,
        techLabel: String = ""
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val text = if (dbm != null) abs(dbm).toString() else "--"
        val badge = shortTechLabel(techLabel)
        val hasBadge = badge.isNotEmpty()

        if (!hasBadge) {
            val isThreeDigits = text.length >= 3
            val textSizeVal = if (showDataDot) {
                if (isThreeDigits) 58f else 72f
            } else {
                if (isThreeDigits) 70f else 82f
            }
            val scaleXVal = if (showDataDot) {
                if (isThreeDigits) 0.84f else 0.96f
            } else {
                if (isThreeDigits) 0.88f else 1.0f
            }

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.LEFT
                textSize = textSizeVal
                textScaleX = scaleXVal
            }

            val textWidth = paint.measureText(text)
            val dotRadius = if (showDataDot) 7.5f else 0f
            val dotGap = if (showDataDot) 7f else 0f
            val groupWidth = if (showDataDot) (dotRadius * 2f + dotGap + textWidth) else textWidth
            val groupStartX = ((SIZE - groupWidth) / 2f).coerceAtLeast(1f)

            val fm = paint.fontMetrics
            val y = (SIZE / 2f) - (fm.ascent + fm.descent) / 2f

            if (showDataDot) {
                val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(groupStartX + dotRadius, SIZE / 2f, dotRadius, dotPaint)
                canvas.drawText(text, groupStartX + dotRadius * 2f + dotGap, y, paint)
            } else {
                canvas.drawText(text, groupStartX, y, paint)
            }
            return bitmap
        }

        // Larger two-zone layout: bold network badge at top + oversized dBm digits below
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            textSize = 31f
            textScaleX = 0.98f
        }
        val badgeFm = badgePaint.fontMetrics
        val badgeTop = 1f
        val badgeBottom = badgeTop + (badgeFm.descent - badgeFm.ascent) + 2f
        val badgeBaseline = badgeBottom - badgeFm.descent - 1f
        canvas.drawText(badge, SIZE / 2f, badgeBaseline, badgePaint)

        val numAreaTop = badgeBottom + 1f
        val numAreaBottom = SIZE - 1f
        val numAreaHeight = numAreaBottom - numAreaTop
        val numAreaCenterY = numAreaTop + numAreaHeight / 2f

        val isThreeDigits = text.length >= 3
        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            textSize = when {
                showDataDot && isThreeDigits -> 49f
                showDataDot -> 58f
                isThreeDigits -> 56f
                else -> 66f
            }
            textScaleX = if (isThreeDigits) 0.86f else 0.96f
        }

        val numWidth = numPaint.measureText(text)
        val dotRadius = if (showDataDot) 6.5f else 0f
        val dotGap = if (showDataDot) 6f else 0f
        val rowWidth = if (showDataDot) (dotRadius * 2f + dotGap + numWidth) else numWidth
        val rowStartX = ((SIZE - rowWidth) / 2f).coerceAtLeast(1f)

        val numFm = numPaint.fontMetrics
        val numBaseline = numAreaCenterY - (numFm.ascent + numFm.descent) / 2f

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(rowStartX + dotRadius, numAreaCenterY, dotRadius, dotPaint)
            canvas.drawText(text, rowStartX + dotRadius * 2f + dotGap, numBaseline, numPaint)
        } else {
            canvas.drawText(text, rowStartX, numBaseline, numPaint)
        }

        return bitmap
    }

    fun renderBarsIcon(
        bars: Int,
        showDataDot: Boolean = false,
        techLabel: String = ""
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val badge = shortTechLabel(techLabel)
        val hasBadge = badge.isNotEmpty()

        val barsTop: Float
        val barsBottom: Float
        if (hasBadge) {
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                textSize = 31f
                textScaleX = 0.98f
            }
            val badgeFm = badgePaint.fontMetrics
            barsTop = 1f + (badgeFm.descent - badgeFm.ascent) + 4f
            barsBottom = SIZE - 2f
            canvas.drawText(badge, SIZE / 2f, 1f - badgeFm.ascent, badgePaint)
        } else {
            barsTop = 8f
            barsBottom = SIZE - 4f
        }

        val totalHeight = barsBottom - barsTop
        val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(80, 255, 255, 255)
            style = Paint.Style.FILL
        }

        val barWidth = 17f
        val gap = 6f
        val totalWidth = barWidth * 4 + gap * 3
        val dotSpace = if (showDataDot) 16f else 0f
        val startX = (((SIZE - (totalWidth + dotSpace)) / 2f) + dotSpace).coerceAtLeast(16f)
        val ratios = floatArrayOf(0.32f, 0.54f, 0.77f, 1.0f)
        val radius = 5f

        for (i in 0 until 4) {
            val barH = totalHeight * ratios[i]
            val left = startX + i * (barWidth + gap)
            val top = barsBottom - barH
            val rect = RectF(left, top, left + barWidth, barsBottom)
            canvas.drawRoundRect(rect, radius, radius, if (i < bars) activePaint else inactivePaint)
        }

        if (showDataDot) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(8f, barsBottom - 7f, 6.5f, dotPaint)
        }

        if (bars == 0) {
            val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                strokeWidth = 7.5f
                strokeCap = Paint.Cap.ROUND
            }
            val xTop = barsTop + 3f
            val xSize = (totalHeight * 0.50f).coerceIn(16f, 26f)
            canvas.drawLine(startX, xTop, startX + xSize, xTop + xSize, xPaint)
            canvas.drawLine(startX + xSize, xTop, startX, xTop + xSize, xPaint)
        }

        return bitmap
    }
}
