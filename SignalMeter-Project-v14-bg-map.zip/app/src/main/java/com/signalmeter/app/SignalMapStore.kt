package com.signalmeter.app

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class SignalMapPoint(
    val id: Long,
    val lat: Double,
    val lon: Double,
    val dbm: Int,
    val tech: String,
    val simInfo: String,
    val accuracyMeters: Float,
    val timestampMs: Long
)

object SignalMapStore {

    private const val FILE_NAME = "signal_map_points.json"
    private const val MAX_POINTS = 5000

    fun colorForDbm(dbm: Int): Int {
        return when {
            dbm >= -85 -> Color.rgb(34, 197, 94)    // Зелёный: отличный сигнал
            dbm >= -98 -> Color.rgb(163, 230, 53)   // Салатовый: хороший
            dbm >= -108 -> Color.rgb(250, 204, 21)  // Жёлтый: средний
            dbm >= -118 -> Color.rgb(249, 115, 22)  // Оранжевый: слабый
            else -> Color.rgb(239, 68, 68)          // Красный: очень слабый / на грани обрыва
        }
    }

    fun labelForDbm(dbm: Int): String {
        return when {
            dbm >= -85 -> "Отлично"
            dbm >= -98 -> "Хорошо"
            dbm >= -108 -> "Средне"
            dbm >= -118 -> "Слабо"
            else -> "Плохо"
        }
    }

    private fun storeFile(context: Context): File {
        return File(context.filesDir, FILE_NAME)
    }

    @Synchronized
    fun loadPoints(context: Context): MutableList<SignalMapPoint> {
        val file = storeFile(context)
        if (!file.exists()) return mutableListOf()
        return try {
            val raw = file.readText(Charsets.UTF_8)
            val arr = JSONArray(raw)
            val result = mutableListOf<SignalMapPoint>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                if (!obj.has("lat") || !obj.has("lon") || !obj.has("dbm")) continue
                result.add(
                    SignalMapPoint(
                        id = obj.optLong("id", i.toLong() + 1L),
                        lat = obj.getDouble("lat"),
                        lon = obj.getDouble("lon"),
                        dbm = obj.getInt("dbm"),
                        tech = obj.optString("tech", ""),
                        simInfo = obj.optString("simInfo", ""),
                        accuracyMeters = obj.optDouble("accuracy", 0.0).toFloat(),
                        timestampMs = obj.optLong("ts", 0L)
                    )
                )
            }
            result
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun savePoints(context: Context, points: List<SignalMapPoint>) {
        val trimmed = if (points.size > MAX_POINTS) {
            points.takeLast(MAX_POINTS)
        } else {
            points
        }
        val arr = JSONArray()
        for (p in trimmed) {
            val obj = JSONObject().apply {
                put("id", p.id)
                put("lat", p.lat)
                put("lon", p.lon)
                put("dbm", p.dbm)
                put("tech", p.tech)
                put("simInfo", p.simInfo)
                put("accuracy", p.accuracyMeters.toDouble())
                put("ts", p.timestampMs)
            }
            arr.put(obj)
        }
        try {
            storeFile(context).writeText(arr.toString(2), Charsets.UTF_8)
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun appendPoint(context: Context, point: SignalMapPoint): List<SignalMapPoint> {
        val list = loadPoints(context)
        list.add(point)
        savePoints(context, list)
        return loadPoints(context)
    }

    @Synchronized
    fun clearPoints(context: Context) {
        val file = storeFile(context)
        if (file.exists()) {
            file.delete()
        }
    }

    fun exportToJsonString(context: Context): String {
        val points = loadPoints(context)
        val root = JSONObject().apply {
            put("app", "SignalMeter")
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            val arr = JSONArray()
            for (p in points) {
                arr.put(
                    JSONObject().apply {
                        put("lat", p.lat)
                        put("lon", p.lon)
                        put("dbm", p.dbm)
                        put("tech", p.tech)
                        put("simInfo", p.simInfo)
                        put("accuracy", p.accuracyMeters.toDouble())
                        put("ts", p.timestampMs)
                    }
                )
            }
            put("points", arr)
        }
        return root.toString(2)
    }

    @Synchronized
    fun importFromJsonString(context: Context, rawText: String, merge: Boolean = true): Int {
        val trimmed = rawText.trim()
        val arr = if (trimmed.startsWith("{")) {
            JSONObject(trimmed).optJSONArray("points") ?: JSONArray()
        } else if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            return 0
        }

        val imported = mutableListOf<SignalMapPoint>()
        var baseId = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (!obj.has("lat") || !obj.has("lon") || !obj.has("dbm")) continue
            val lat = obj.getDouble("lat")
            val lon = obj.getDouble("lon")
            val dbm = obj.getInt("dbm")
            if (lat !in -90.0..90.0 || lon !in -180.0..180.0) continue
            imported.add(
                SignalMapPoint(
                    id = baseId + i,
                    lat = lat,
                    lon = lon,
                    dbm = dbm,
                    tech = obj.optString("tech", ""),
                    simInfo = obj.optString("simInfo", ""),
                    accuracyMeters = obj.optDouble("accuracy", 0.0).toFloat(),
                    timestampMs = obj.optLong("ts", System.currentTimeMillis())
                )
            )
        }

        if (imported.isEmpty()) return 0

        val finalList = if (merge) {
            val existing = loadPoints(context)
            existing.addAll(imported)
            existing
        } else {
            imported
        }
        savePoints(context, finalList)
        return imported.size
    }
}
