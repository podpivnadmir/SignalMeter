package com.signalmeter.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telephony.CellInfo
import android.telephony.CellSignalStrengthGsm
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.CellSignalStrengthWcdma
import android.telephony.SignalStrength
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager

class SignalMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "signal_meter_status_v1"
        const val NOTIFICATION_ID = 1001
        const val ACTION_REFRESH = "com.signalmeter.app.ACTION_REFRESH"
        const val ACTION_STOP = "com.signalmeter.app.ACTION_STOP"
        private const val POLL_INTERVAL_MS = 5000L
    }

    private lateinit var notificationManager: NotificationManager
    private lateinit var powerManager: PowerManager
    private var activeTelephonyManager: TelephonyManager? = null
    private var telephonyCallback: SignalTelephonyCallback? = null

    private var lastDisplayInfo: TelephonyDisplayInfo? = null
    private var lastSignalStrength: SignalStrength? = null
    private var currentSubId: Int = SubscriptionManager.INVALID_SUBSCRIPTION_ID

    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (SignalState.isRunning) {
                if (powerManager.isInteractive) {
                    checkSubscriptionAndPoll()
                }
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setServiceEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }

        SignalState.isRunning = true
        Prefs.setServiceEnabled(this, true)

        val initialNotification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        setupTelephonyListener(forceReset = true)
        handler.removeCallbacks(pollRunnable)
        handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)

        return START_STICKY
    }

    override fun onDestroy() {
        SignalState.isRunning = false
        handler.removeCallbacks(pollRunnable)
        unregisterListener()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Уровень сигнала (dBm / палки)",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Постоянный индикатор реального уровня сигнала в статус-баре"
            setSound(null, null)
            enableVibration(false)
            enableLights(false)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        notificationManager.createNotificationChannel(channel)
    }

    private fun resolveTargetSubId(): Pair<Int, String> {
        val subManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        val slotPref = Prefs.getSimSlot(this)

        val subs = try {
            subManager.activeSubscriptionInfoList ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        }

        if (slotPref == Prefs.SIM_1 || slotPref == Prefs.SIM_2) {
            val targetSlotIndex = if (slotPref == Prefs.SIM_1) 0 else 1
            val found = subs.firstOrNull { it.simSlotIndex == targetSlotIndex }
            if (found != null) {
                val carrier = found.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM ${targetSlotIndex + 1}"
                return Pair(found.subscriptionId, carrier)
            }
        }

        val dataSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        if (dataSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            val found = subs.firstOrNull { it.subscriptionId == dataSubId }
            val carrier = found?.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM"
            return Pair(dataSubId, carrier)
        }

        val first = subs.firstOrNull()
        if (first != null) {
            val carrier = first.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM 1"
            return Pair(first.subscriptionId, carrier)
        }

        return Pair(SubscriptionManager.INVALID_SUBSCRIPTION_ID, "SIM")
    }

    private fun setupTelephonyListener(forceReset: Boolean) {
        val (targetSubId, simName) = resolveTargetSubId()
        SignalState.simLabel = simName

        if (!forceReset && targetSubId == currentSubId && telephonyCallback != null) {
            return
        }

        unregisterListener()
        currentSubId = targetSubId

        val baseTm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val tm = if (targetSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            baseTm.createForSubscriptionId(targetSubId)
        } else {
            baseTm
        }
        activeTelephonyManager = tm

        val cb = SignalTelephonyCallback()
        telephonyCallback = cb
        try {
            tm.registerTelephonyCallback(mainExecutor, cb)
        } catch (_: SecurityException) {
            SignalState.networkLabel = "Нет разрешения «Телефон»"
            updateNotification()
            return
        }

        tm.signalStrength?.let {
            lastSignalStrength = it
        }
        recomputeAndNotify()
    }

    private fun checkSubscriptionAndPoll() {
        val (targetSubId, _) = resolveTargetSubId()
        if (targetSubId != currentSubId) {
            setupTelephonyListener(forceReset = true)
            return
        }
        activeTelephonyManager?.signalStrength?.let {
            lastSignalStrength = it
            recomputeAndNotify()
        }
    }

    private fun unregisterListener() {
        val cb = telephonyCallback
        val tm = activeTelephonyManager
        if (cb != null && tm != null) {
            try {
                tm.unregisterTelephonyCallback(cb)
            } catch (_: Exception) {
            }
        }
        telephonyCallback = null
    }

    private inner class SignalTelephonyCallback :
        TelephonyCallback(),
        TelephonyCallback.SignalStrengthsListener,
        TelephonyCallback.DisplayInfoListener {

        override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
            lastSignalStrength = signalStrength
            recomputeAndNotify()
        }

        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
            lastDisplayInfo = telephonyDisplayInfo
            recomputeAndNotify()
        }
    }

    private fun recomputeAndNotify() {
        val strength = lastSignalStrength
        var dbm: Int? = null
        var hasRealNr = false
        var detectedTech = "Нет сети"

        if (strength != null) {
            val nrList = strength.getCellSignalStrengths(CellSignalStrengthNr::class.java)
            val lteList = strength.getCellSignalStrengths(CellSignalStrengthLte::class.java)
            val wcdmaList = strength.getCellSignalStrengths(CellSignalStrengthWcdma::class.java)
            val gsmList = strength.getCellSignalStrengths(CellSignalStrengthGsm::class.java)

            val nrRsrp = nrList.firstOrNull()?.ssRsrp?.takeIf { isValidDbm(it) }
            val lteRsrp = lteList.firstOrNull()?.rsrp?.takeIf { isValidDbm(it) }
            val wcdmaDbm = wcdmaList.firstOrNull()?.dbm?.takeIf { isValidDbm(it) }
            val gsmDbm = gsmList.firstOrNull()?.dbm?.takeIf { isValidDbm(it) }

            when {
                nrRsrp != null -> {
                    dbm = nrRsrp
                    hasRealNr = true
                    detectedTech = "5G NR"
                }
                lteRsrp != null -> {
                    dbm = lteRsrp
                    detectedTech = "LTE"
                }
                wcdmaDbm != null -> {
                    dbm = wcdmaDbm
                    detectedTech = "3G"
                }
                gsmDbm != null -> {
                    dbm = gsmDbm
                    detectedTech = "2G / E"
                }
            }
        }

        val displayInfo = lastDisplayInfo
        if (displayInfo != null) {
            detectedTech = formatNetworkType(displayInfo, hasRealNr, detectedTech)
        }

        val scale = Prefs.getScale(this)
        val bars = Prefs.calculateBars(dbm, scale)

        SignalState.currentDbm = dbm
        SignalState.currentBars = bars
        SignalState.networkLabel = detectedTech
        SignalState.isReal5g = hasRealNr

        updateNotification()
    }

    private fun isValidDbm(value: Int): Boolean {
        return value != CellInfo.UNAVAILABLE && value in -150..-30
    }

    private fun formatNetworkType(
        info: TelephonyDisplayInfo,
        hasRealNr: Boolean,
        fallback: String
    ): String {
        return when (info.overrideNetworkType) {
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED ->
                if (hasRealNr) "5G+" else "LTE+ (метка 5G)"
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA ->
                if (hasRealNr) "5G NSA" else "LTE (метка 5G)"
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_ADVANCED_PRO,
            TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_CA -> "LTE+"
            else -> when (info.networkType) {
                TelephonyManager.NETWORK_TYPE_NR -> "5G SA"
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                TelephonyManager.NETWORK_TYPE_HSPAP,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
                TelephonyManager.NETWORK_TYPE_EDGE -> "E"
                TelephonyManager.NETWORK_TYPE_GPRS -> "G"
                else -> fallback
            }
        }
    }

    private fun buildNotification(): Notification {
        val dbm = SignalState.currentDbm
        val bars = SignalState.currentBars
        val iconMode = Prefs.getIconMode(this)

        val bitmap = if (iconMode == Prefs.MODE_BARS) {
            IconRenderer.renderBarsIcon(bars)
        } else {
            IconRenderer.renderDbmIcon(dbm)
        }

        val dbmText = if (dbm != null) "$dbm dBm" else "-- dBm"
        val title = "$dbmText  •  ${SignalState.networkLabel}"
        val scaleName = if (Prefs.getScale(this) == Prefs.SCALE_SOFT) "Samsung EU" else "Samsung"
        val subtitle = "${SignalState.simLabel}  •  $bars/4 палки ($scaleName)"

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(Icon.createWithBitmap(bitmap))
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(pendingIntent)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .build()
    }

    private fun updateNotification() {
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification())
        } catch (_: SecurityException) {
        }
    }
}
