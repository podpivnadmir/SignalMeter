package com.signalmeter.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatusBadge: TextView
    private lateinit var tvDbmValue: TextView
    private lateinit var tvDetails: TextView

    private val uiHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            updateUiCard()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val phoneGranted = results[Manifest.permission.READ_PHONE_STATE] == true ||
            hasPermission(Manifest.permission.READ_PHONE_STATE)
        val notifGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            results[Manifest.permission.POST_NOTIFICATIONS] == true ||
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)

        if (phoneGranted && notifGranted) {
            startMonitorService()
        } else {
            Toast.makeText(
                this,
                "Нужны разрешения «Телефон» и «Уведомления» для показа сигнала",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatusBadge = findViewById(R.id.tvStatusBadge)
        tvDbmValue = findViewById(R.id.tvDbmValue)
        tvDetails = findViewById(R.id.tvDetails)

        val btnStart = findViewById<MaterialButton>(R.id.btnStart)
        val btnStop = findViewById<MaterialButton>(R.id.btnStop)
        val btnAppSettings = findViewById<MaterialButton>(R.id.btnAppSettings)
        val rgIconMode = findViewById<RadioGroup>(R.id.rgIconMode)
        val rgScale = findViewById<RadioGroup>(R.id.rgScale)
        val rgSimSlot = findViewById<RadioGroup>(R.id.rgSimSlot)
        val swAutostart = findViewById<MaterialSwitch>(R.id.swAutostart)

        // Restore saved state
        rgIconMode.check(
            if (Prefs.getIconMode(this) == Prefs.MODE_BARS) R.id.rbModeBars else R.id.rbModeDbm
        )
        rgScale.check(
            if (Prefs.getScale(this) == Prefs.SCALE_SOFT) R.id.rbScaleSoft else R.id.rbScaleStrict
        )
        rgSimSlot.check(
            when (Prefs.getSimSlot(this)) {
                Prefs.SIM_1 -> R.id.rbSim1
                Prefs.SIM_2 -> R.id.rbSim2
                else -> R.id.rbSimAuto
            }
        )
        swAutostart.isChecked = Prefs.isAutostart(this)

        rgIconMode.setOnCheckedChangeListener { _, checkedId ->
            Prefs.setIconMode(
                this,
                if (checkedId == R.id.rbModeBars) Prefs.MODE_BARS else Prefs.MODE_DBM
            )
            refreshIfRunning()
        }

        rgScale.setOnCheckedChangeListener { _, checkedId ->
            Prefs.setScale(
                this,
                if (checkedId == R.id.rbScaleSoft) Prefs.SCALE_SOFT else Prefs.SCALE_STRICT
            )
            refreshIfRunning()
        }

        rgSimSlot.setOnCheckedChangeListener { _, checkedId ->
            val slot = when (checkedId) {
                R.id.rbSim1 -> Prefs.SIM_1
                R.id.rbSim2 -> Prefs.SIM_2
                else -> Prefs.SIM_AUTO
            }
            Prefs.setSimSlot(this, slot)
            refreshIfRunning()
        }

        swAutostart.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setAutostart(this, isChecked)
        }

        btnStart.setOnClickListener {
            requestPermissionsAndStart()
        }

        btnStop.setOnClickListener {
            val stopIntent = Intent(this, SignalMonitorService::class.java).apply {
                action = SignalMonitorService.ACTION_STOP
            }
            startService(stopIntent)
            updateUiCard()
        }

        btnAppSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        uiHandler.post(uiTicker)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isEmpty()) {
            startMonitorService()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startMonitorService() {
        val intent = Intent(this, SignalMonitorService::class.java)
        startForegroundService(intent)
        updateUiCard()
    }

    private fun refreshIfRunning() {
        if (SignalState.isRunning) {
            val intent = Intent(this, SignalMonitorService::class.java).apply {
                action = SignalMonitorService.ACTION_REFRESH
            }
            startForegroundService(intent)
        }
    }

    private fun updateUiCard() {
        if (!SignalState.isRunning) {
            tvStatusBadge.text = "● Сервис остановлен"
            tvDbmValue.text = "-- dBm"
            tvDetails.text = "Нажмите «Запустить», чтобы вывести значок в статус-бар"
            return
        }

        val dbm = SignalState.currentDbm
        tvStatusBadge.text = "● Мониторинг активен"
        tvDbmValue.text = if (dbm != null) "$dbm dBm" else "-- dBm"
        val scaleName = if (Prefs.getScale(this) == Prefs.SCALE_SOFT) "Samsung EU" else "Samsung"
        tvDetails.text = "${SignalState.simLabel} • ${SignalState.networkLabel} • ${SignalState.currentBars}/4 палки ($scaleName)"
    }
}
