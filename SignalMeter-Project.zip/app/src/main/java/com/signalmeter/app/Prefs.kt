package com.signalmeter.app

import android.content.Context

object Prefs {
    private const val PREFS_NAME = "signal_meter_prefs"

    const val MODE_DBM = 0
    const val MODE_BARS = 1

    const val SCALE_STRICT = 0 // -115, -105, -95, -85
    const val SCALE_SOFT = 1   // -120, -110, -100, -90

    const val SIM_AUTO = 0
    const val SIM_1 = 1
    const val SIM_2 = 2

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getIconMode(ctx: Context): Int = prefs(ctx).getInt("icon_mode", MODE_DBM)
    fun setIconMode(ctx: Context, mode: Int) = prefs(ctx).edit().putInt("icon_mode", mode).apply()

    fun getScale(ctx: Context): Int = prefs(ctx).getInt("scale", SCALE_STRICT)
    fun setScale(ctx: Context, scale: Int) = prefs(ctx).edit().putInt("scale", scale).apply()

    fun getSimSlot(ctx: Context): Int = prefs(ctx).getInt("sim_slot", SIM_AUTO)
    fun setSimSlot(ctx: Context, slot: Int) = prefs(ctx).edit().putInt("sim_slot", slot).apply()

    fun isAutostart(ctx: Context): Boolean = prefs(ctx).getBoolean("autostart", true)
    fun setAutostart(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("autostart", enabled).apply()

    fun isServiceEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("service_enabled", false)
    fun setServiceEnabled(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean("service_enabled", enabled).apply()

    fun calculateBars(dbm: Int?, scale: Int): Int {
        if (dbm == null) return 0
        val thresholds = if (scale == SCALE_SOFT) {
            intArrayOf(-120, -110, -100, -90)
        } else {
            intArrayOf(-115, -105, -95, -85)
        }
        return when {
            dbm >= thresholds[3] -> 4
            dbm >= thresholds[2] -> 3
            dbm >= thresholds[1] -> 2
            dbm >= thresholds[0] -> 1
            else -> 0
        }
    }
}
